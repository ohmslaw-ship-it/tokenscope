# Tokenscope

Paste a prompt, see every token, and find out what it costs to run at production volume.

**Role:** Solo. I defined the product, designed the interface as HTML mockups, and built the working app in Cursor.
**Timeline:** November 2026
**Tools:** Next.js, TypeScript, Tailwind CSS, Motion, NumberFlow, and gpt-tokenizer. Designed as static HTML, then built in Cursor with Composer.
**Live demo:** [tokenscope-murex.vercel.app](https://tokenscope-murex.vercel.app/)
**Code:** [github.com/ohmslaw-ship-it/tokenscope](https://github.com/ohmslaw-ship-it/tokenscope)

## The problem

If you ship an LLM feature, the price list is per million tokens. That number is hard to feel. A 400-token support prompt looks cheap until you run it 5,000 times a day for a month. Most playgrounds show a token count, or a cost per request, and stop there. Advice online often starts and ends with "trim your prompt."

I wanted a tool that answers a more useful question: what does this prompt cost per month, on which model, and which part of the request is actually driving the bill?

## Who it's for

Tokenscope is for product managers, designers, and engineers who are about to ship an LLM feature and need to choose a model or a volume they can stand behind. It is a browser demo, not a production billing dashboard, and it should be understandable in a minute without an account or an API key.

The app ships with three sample prompts: a support bot, a long-context RAG document, and a coding agent. Edits, model, currency, and volume are saved in the browser, with a reset back to the sample.

## Key insight

On the support-bot sample, a 400-token prompt and a 400-token reply at 5,000 requests a day costs ₹67,276.80 a month on GPT-6.2 Sol. 83.3% of that bill is the reply (₹56,064). Gemini 3.8 Flash, at its promo rate through 31 Dec 2026, runs the same prompt for ₹25,228.80, which is ₹42,048 less. Cutting an entire few-shot example saves ₹2,999 a month. Trimming the prompt helps, but it is usually not the main lever.

![Inspect view on the support-bot sample](inspect-support.png)

The RAG sample flips this. A 2,394-token pasted document makes the prompt the larger share of cost, and the reply is 33.1% of the bill on Sol (₹1,05,820.80 a month at the same volume). The right lever depends on the shape of the prompt, which is why the presets exist.

![Inspect view on the RAG, long context sample](inspect-rag.png)

## Design decisions

**Lead with the monthly number, not a chart.** The first thing you see is a large rolling cost, then a short line that names the model, the volume, and the reply's share. I left out charts, badges, and quality scores. I cannot honestly score whether one model writes a better answer than another. The product has one job: show what this costs.

**A typographic interface, not an "AI" look.** I designed the screens as HTML mockups and reviewed them as screenshots before writing the app. The direction I kept is a dark navy layout with Geist and Geist Mono, and very few decorations. I rejected the usual AI-tool look: glows, chips, and sparklines.

**Compare is a sentence, then a ranked table.** The Compare view opens with a headline such as "Gemini 3.8 Flash runs this prompt for ₹42,048 less a month than GPT-6.2 Sol." Under that is the same prompt across five models, with cost bars and rates. Only the user message is editable there, because that is the part that changes in production. Clicking a row selects that model and opens it in Inspect, so the two views feel like one product.

![Compare view: a sentence headline and a ranked table of five models](compare.png)

**Be honest about what the numbers are.** Token counts for GPT-5.6 Terra are exact. The other models are labelled "est.", with a tooltip explaining that they use OpenAI's o200k tokenizer and may differ by a few percent. Prices are dated (20 Nov 2026) and rupees use a fixed rate of 93.44. If you clear every prompt box, the reply cost still counts, because a model still bills for the answer.

## Build and iteration

I built the app in Cursor and tested it on the live site, then fixed what actually broke.

Typing used to hitch, because every keystroke waited on the tokenizer. The text now renders immediately, and token counting runs in a Web Worker, debounced, so a large paste does not freeze the page. The rolling cost number was clipping mid-animation, so I had to give it room. After I added saved state, every refresh threw a React hydration error. The first render now matches the server, and stored state is applied after that, so the number still rolls up once from zero.

The tablet layout kept the desktop grid, so bars collapsed and the page scrolled sideways. Mid-widths now use the stacked mobile rows. Rupee amounts were also mixed: some used Indian grouping (₹2,69,107) and some used Western grouping (₹201,830). They now follow the currency: en-IN for rupees, en-US for dollars.

Two content bugs were easy to miss. The "cut this example" suggestion was offering to delete the RAG document and the agent's tool list, so it now only appears on real few-shot examples. An empty prompt was also treating the reply as zero tokens. The reply still costs money, so the math now keeps it.

![Hovering a trim suggestion highlights the example it would remove](inspect-trim.png)

## What I'd do next

The model names are a fictional, near-future lineup for the demo, and list prices will change. I would start by swapping in a current list, adding exact tokenizers for Claude and Gemini, and giving teammates a shareable link instead of relying on local storage.

A clearer "what if the reply is shorter" comparison is the other product gap. The reply length is already editable, but the insight would land harder if you could see two reply lengths side by side.

I have not sat with people who ship LLM features and watched them use this, so the next step is that, not more visual polish.

## Links

- Live demo: [tokenscope-murex.vercel.app](https://tokenscope-murex.vercel.app/)
- Source: [github.com/ohmslaw-ship-it/tokenscope](https://github.com/ohmslaw-ship-it/tokenscope)

Screenshots in this folder: `inspect-support.png`, `inspect-rag.png`, `compare.png`, `inspect-trim.png`, and `mobile.png` (390px).
